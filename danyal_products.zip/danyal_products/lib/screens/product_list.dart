import 'package:flutter/material.dart';
import '../models/product_model.dart';
import '../widgets/product_tile.dart';
import 'product_detail.dart';

class ProductList extends StatelessWidget {
  final List<Product> products = [
    Product(
      title: 'Galaxy S24 FE',
      description: 'Color: blue, Ram: 8gb , Rom: 256gb. Resize it, retouch it with Photo Assist Stunning low-light portraits with Galaxy ProVisual Engine Hyper-realistic gaming experience',
      price: 50.99,
      imageUrl: 'https://www.androidheadlines.com/wp-content/uploads/2024/09/AH-Samsung-Galaxy-S24-FE-exclusive-all-colors-image-28-1420x1420.webp',
    ),
    Product(
      title: 'Iphone 13 pro Max',
      description: 'Color: Goldan, Ram: 16gb , Rom: 256gb. Resize it, retouch it with Photo Assist Stunning low-light portraits with Galaxy ProVisual Engine Hyper-realistic gaming experience',
      price: 49.99,
      imageUrl: 'https://static3.webx.pk/files/4012/Images/ezgif.com-gif-maker-10-4012-728375-040122063224029.jpg',
    ),
    Product(
      title: 'Nokia 14x',
      description: 'Color: DarkBlue, Ram: 4gb , Rom: 32gb.  low-light portraits with Nokia ProVisual Engine Hyper-realistic gaming experience',
      price: 50.99,
      imageUrl: 'https://www.androidheadlines.com/wp-content/uploads/2024/09/AH-Samsung-Galaxy-S24-FE-exclusive-all-colors-image-28-1420x1420.webp',
    ),
    Product(
      title: 'Galaxy s23',
      description: 'Color: Black, Ram: 16gb , Rom: 256gb.touch it with Photo Assist Stunning low-light portraits with Galaxy ProVisual Engine Hyper-realistic gaming experience',
      price: 56.99,
      imageUrl: 'https://www.androidheadlines.com/wp-content/uploads/2024/09/AH-Samsung-Galaxy-S24-FE-exclusive-all-colors-image-27-1420x1420.webp',
    ),
    Product(
      title: 'Google pixel 9',
      description: 'Color: black, Ram: 12gb , Rom: 128gb. Resize it, retouch it with Photo Assist Stunning low-light portraits with Galaxy ProVisual Engine Hyper-realistic gaming experience',
      price: 100.99,
      imageUrl: 'https://www.androidheadlines.com/wp-content/uploads/2024/09/AH-Samsung-Galaxy-S24-FE-exclusive-all-colors-image-28-1420x1420.webp',
    ),
    Product(
      title: 'Iphone 16',
      description: 'Color: white, Ram: 32gb , Rom: 1TB. Resize it, retouch it with Photo Assist Stunning low-light portraits with Galaxy ProVisual Engine Hyper-realistic gaming experience',
      price: 200.00,
      imageUrl: 'https://static3.webx.pk/files/4012/Images/ezgif.com-gif-maker-10-4012-728375-040122063224029.jpg',
    ),
    Product(
      title: 'Galaxy S24 FE',
      description: 'Color: blue, Ram: 8gb , Rom: 256gb. Resize it, retouch it with Photo Assist Stunning low-light portraits with Galaxy ProVisual Engine Hyper-realistic gaming experience',
      price: 50.99,
      imageUrl: 'https://www.androidheadlines.com/wp-content/uploads/2024/09/AH-Samsung-Galaxy-S24-FE-exclusive-all-colors-image-28-1420x1420.webp',
    ),
    Product(
      title: 'Iphone 13 pro Max',
      description: 'Color: Goldan, Ram: 16gb , Rom: 256gb. Resize it, retouch it with Photo Assist Stunning low-light portraits with Galaxy ProVisual Engine Hyper-realistic gaming experience',
      price: 49.99,
      imageUrl: 'https://static3.webx.pk/files/4012/Images/ezgif.com-gif-maker-10-4012-728375-040122063224029.jpg',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Product List')),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          return ProductTile(
            product: products[index],
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ProductDetail(product: products[index]),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
