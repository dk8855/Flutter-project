package com.example.danyal_products;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
